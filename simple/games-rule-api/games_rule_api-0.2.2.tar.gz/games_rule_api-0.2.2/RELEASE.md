# Release Notes


## 0.2.2
- Added live and ready endpoints with sample code

## 0.2.1
- Added health check


## 0.2.0
- Added polyfactory

## 0.1.0
- Initial release of api package
