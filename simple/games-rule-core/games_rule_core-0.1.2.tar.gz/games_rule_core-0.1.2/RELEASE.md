# Release Notes


## 0.1.2
- added relationships

## 0.1.1
- fix package name

## 0.1.0
- Initial release of package
