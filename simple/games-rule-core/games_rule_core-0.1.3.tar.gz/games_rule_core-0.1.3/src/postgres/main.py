print("high")
