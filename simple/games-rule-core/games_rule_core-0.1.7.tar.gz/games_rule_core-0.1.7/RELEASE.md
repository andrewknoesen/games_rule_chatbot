# Release Notes


## 0.1.7
- fixed model (more)

## 0.1.6
- fixed model

## 0.1.5
- removed extra in sqlmodel

## 0.1.4
- use env variables for login details

## 0.1.3
- added relationships

## 0.1.2
- added relationships

## 0.1.1
- fix package name

## 0.1.0
- Initial release of package
